// Author: William Poti
// Date: May 7th, 2018
// Description: Build a typing test using CoreData. The typing test will allow users to gauge how fast they type on their apple devices
// The users will also be able to save their scores in a highscores entity which will be displayed on screen for the user to check at leasure.
// Also have features to allow change of user interface color and text, reset the test, and reset highscores

import UIKit
import CoreData

class ViewController: UIViewController, UITextFieldDelegate {
    
    // Variables
    var testTimer:Timer?
    var currentlyTesting = false
    var currentCorrectWordCount:Int = 0
    var calculatedWPM:Int?
    // String Interpolation
    var wordsArray:[String] = []
    var wordsString:String = ""
    
    // Outlets
    @IBOutlet weak var wpmLabel: UILabel!
    @IBOutlet weak var wordsLabel: UILabel!
    @IBOutlet weak var testTimerLabel: UILabel!
    @IBOutlet weak var textInputField: UITextField!
    @IBOutlet weak var saveButton: UIButton!

    
    // Sets Interface to Green
    @IBAction func greenButton(_ sender: Any)
    {
        // Sets UI to Green
        view.backgroundColor = .green
        
        // Sets Labels Text Font to Black
        wordsLabel.textColor = UIColor.black
        wpmLabel.textColor = UIColor.black
        testTimerLabel.textColor = UIColor.black
    }
    
    // Sets Interface to Yellow
    @IBAction func yellowButton(_ sender: Any)
    {
        // Sets UI to Yellow
        view.backgroundColor = .yellow
        
        // Sets Labels Text Font to Black
        wordsLabel.textColor = UIColor.black
        wpmLabel.textColor = UIColor.green
        testTimerLabel.textColor = UIColor.black
    }
    
    // Sets Interface to Orange
    @IBAction func blueButton(_ sender: Any)
    {
        // Sets UI to Orange
        view.backgroundColor = .orange
        
        // Sets Labels Text Font Color
        wordsLabel.textColor = UIColor.black
        wpmLabel.textColor = UIColor.black
        testTimerLabel.textColor = UIColor.black
    }
   
    @IBAction func blackButton(_ sender: Any)
    {
        // Sets UI to Black
        view.backgroundColor = .black
        
        // set text color to White & Green
        wordsLabel.textColor = UIColor.white
        wpmLabel.textColor = UIColor.green
        testTimerLabel.textColor = UIColor.green
    }
    
    // Sets Interface to Default
    @IBAction func whiteButton(_ sender: Any)
    {
        // Sets UI to White
        view.backgroundColor = .white
        
        // Sets Labels Text Font to Black
        wordsLabel.textColor = UIColor.black
        wpmLabel.textColor = UIColor.blue
        testTimerLabel.textColor = UIColor.black
    }
    
    // Do any additional setup after loading the view, typically from a nib.
    override func viewDidLoad()
    {
        // Superclassing to make sure everything runs inside of viewDidLoad() & access func resignFirstResponder() -> Bool
        super.viewDidLoad()
       
        // Validates text that was typed by user & Allows access to editing of text inside text input field
        // For Counting Characters for WPM, Matching Characters typed to Words Label, Validates if user is allowed to type next
        textInputField.delegate = self
        
        // Streches Label to fit words from wordsArray on UI
        wordsLabel.sizeToFit()
        
        // Initializes setupTest() on its own; Calls get words, resets timer etc. (see setUpTest)
        self.setupTest()
        
        // Prints typing test words in wordsLabel
        print(wordsString)
        
        // Underlines word being typed (attributed) in words label
        wordsLabel.attributedText = self.setUnderline(words: wordsString)
        
    }
    
    // Function for underlining first word and word being typed using NSAttributedString
    // Setting String into Attributed string to
    func setUnderline(words:String)->NSAttributedString{
        //
        let attributedString = NSMutableAttributedString()
        
        // array for checking which word we're currently on and underline that word
        var cumulativeWordArray = wordsArray
        
        // Optional String
        var wordToUnderline:String?
        
        // switch to count the amount of words typed
        switch currentCorrectWordCount {
        // Case when no words are typed correctly (beginning of Test)
        case 0:
            // declaring wordToUnderline to index 0 on the cumulative word array
            wordToUnderline = cumulativeWordArray[0]
            // appends the word to be underlined using NSAttributedString attributes
            attributedString.append(NSAttributedString(string: "\(wordToUnderline!) ",
                // applies single line underline to first test word (index 0)
                attributes: [.underlineStyle: NSUnderlineStyle.styleSingle.rawValue]))
            
            // removes first word from array
            cumulativeWordArray.remove(at: 0)
            
            // converts string and appends word
            var stringConversion:String = String()
            for word in cumulativeWordArray{
                stringConversion.append("\(word) ")
            }
            // add underlining
            attributedString.append(NSAttributedString(string: stringConversion,
                                                       attributes: [.underlineStyle: NSUnderlineStyle.styleNone.rawValue]))
            break
        default:
            // declaring next word to be underlined
            wordToUnderline = cumulativeWordArray[currentCorrectWordCount]
            
            // variables for before selection and after selection
            var wordsBeforeSelection:String = ""
            var wordsAfterSelection:String = ""
            
            // index of before array set to current word count - 1 to access word before the selected word
            let indexBefore = currentCorrectWordCount - 1
            let beforeArray = cumulativeWordArray[0...indexBefore]
            for word in beforeArray{
                wordsBeforeSelection.append("\(word) ")
            }
            // sets array index to current correct word + 1
            let indexAfter = currentCorrectWordCount + 1
            // if index after less than cumalitive word array - 1 let cumulativeowrd array be indexAfter and cumlativewordarray count -1
            if indexAfter <= (cumulativeWordArray.count - 1){
                let afterArray = cumulativeWordArray[indexAfter...cumulativeWordArray.count - 1]
                for word in afterArray{
                    // append word
                    wordsAfterSelection.append("\(word) ")
                }
                
            }
            
            // before the word dont underline
            attributedString.append(NSAttributedString(string: wordsBeforeSelection,
                                                       attributes: [.underlineStyle: NSUnderlineStyle.styleNone.rawValue]))
            // underline the word when selected
            attributedString.append(NSAttributedString(string: "\(wordToUnderline!) ",
                attributes: [.underlineStyle: NSUnderlineStyle.styleSingle.rawValue]))
            
            // after the selected word remove underline
            attributedString.append(NSAttributedString(string: wordsAfterSelection,
                                                       attributes: [.underlineStyle: NSUnderlineStyle.styleNone.rawValue]))
            
            
            
            cumulativeWordArray.remove(at: currentCorrectWordCount)
            
            
            break
        }
        
        return attributedString
    }
    
    // returns text field
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textInputField.resignFirstResponder()
        return true
    }
    
    // validated if user is typing to start test
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if currentlyTesting == false{
            currentlyTesting = true
            self.startTest()
        }
        // if wrong word typed -1 from current correct word count
        let currentTextWords = textField.text?.components(separatedBy: " ")
        var workingArray:[String] = []
        workingArray.append(contentsOf: wordsArray)
        if currentCorrectWordCount > 0{
            workingArray.removeSubrange(0...currentCorrectWordCount - 1)
        }
        // if words matched +1 current correct word count
        for word in currentTextWords!{
            for wordMatch in workingArray{
                if wordMatch == word{
                    currentCorrectWordCount = currentCorrectWordCount + 1
                }
            }
        }
        
        wordsLabel.attributedText = nil
        wordsLabel.attributedText = self.setUnderline(words: wordsString)
        return true
    }
    
    // Brings up Save Score Controller
    @IBAction func saveButtonTapped(_ sender: Any) {
        let saveView:SaveScoreViewController = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SaveScoreViewController") as! SaveScoreViewController
        saveView.wpmCount = calculatedWPM!
        self.present(saveView, animated: true, completion: nil)
    }
    
    // Resets Test on tap
    @IBAction func resetTapped(_ sender: Any) {
        // runs reset test
        self.resetTest()
    }
    
    // Switches to Highscore View Controller
    @IBAction func highScoresTapped(_ sender: Any) {
        let highScoresView:HighScoresViewController = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HighScoresViewController") as! HighScoresViewController
        self.present(highScoresView, animated: true, completion: nil)
    }

    // setsup test
    func setupTest()
    {
        // Calls Get
        self.getWords()
        //set each word as appendable string
    }
    
    // start test function
    func startTest()
    {
        // test timer
        testTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
        testTimerLabel.isHidden = false
        
    }
   // Function that updates timer
    @objc func updateTimer(){
        let currentCount = Int((testTimerLabel.text)!)
        // if the timer is 0 do the following
        if currentCount == 0{
                self.currentlyTesting = false
                self.testTimerLabel.isHidden = true
                self.wpmLabel.isHidden = false
                self.saveButton.isHidden = false
                self.testTimerLabel.text = "60"
                // sets the wpm based on how many correct words counter
                self.wpmLabel.text = "WPM: \(currentCorrectWordCount)"
                self.calculatedWPM = currentCorrectWordCount
                
            }
            else{
                testTimerLabel.text = "\(currentCount! - 1)"
            }
       
        
        
    }
    
    func correctWordTyped()
    {
        currentCorrectWordCount = 1
    }
    
    // Function to reset timer
    func resetTest()
    {
        // checks if test timer has value
        if testTimer != nil{
            if (testTimer?.isValid)!{
                testTimer?.invalidate()
            }
        }
        
        testTimer = nil
        currentlyTesting = false // is the user testing
        currentCorrectWordCount = 0 // Current Correct Word Count
        calculatedWPM = nil // wpm has no value
        self.testTimerLabel.isHidden = true // is test timer hidden
        self.wpmLabel.isHidden = true // is wpm label hidden
        self.testTimerLabel.text = "60" // sets timer to 60 seconds
        self.saveButton.isHidden = true // is save button hidden
        self.textInputField.text = ""
        self.setupTest() // runs set up test function
        wordsLabel.attributedText = NSMutableAttributedString(string: "", attributes: [:])
        wordsLabel.text = ""
        wordsLabel.attributedText = self.setUnderline(words: wordsString)
        
    }
    
    func getWords()
    {
        // refering to the container
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        // creating a context from the container
        let context = appDelegate.persistentContainer.viewContext
        
        // requesting words from "TestWords"
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"TestWords")
        
        // set to false to access and modify individual parts of the entity
        request.returnsObjectsAsFaults = false
        
        do {
            // sets var results to fetched context
            var results = try context.fetch(request)
            
            if results.count > 0
            {
                for result in results as! [NSManagedObject]
                {
                    if let word = result.value(forKey: "word") as? String
                    {
                        
                         print(word)
                    }
                    
                }
                for _ in 0 ..< results.count * 4 {
                    let card = results.remove(at: Int(arc4random_uniform(UInt32(results.count))))
                    results.insert(card, at: Int(arc4random_uniform(UInt32(results.count))))
                }
                
                // if words array is empty remove all
                if !self.wordsArray.isEmpty{
                    self.wordsArray.removeAll()
                }
                
                for result in results{
                    if let word = (result as AnyObject).value(forKey: "word") as? String{
                        print(word)
                        self.wordsArray.append(word)
                        
                    }
                }
                for word in wordsArray{
                    self.wordsString.append("\(word) ")
                }
            }
            else{
                // no words saved - save new words
                storeWords()
                self.getWords()
            }
        }
        catch{
            
        }
    }
    
    // Stores words array into CoreData TestWords Entity
    func storeWords(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let wordsArray = [
            "abundant",
            "accept",
            "action",
            "admire",
            "adored",
            "adventure",
            "affirmative",
            "agree",
            "alive",
            "alliance",
            "alter",
            "amaze",
            "appreciation",
            "artistic",
            "assertive",
            "astonish",
            "beautiful",
            "believe",
            "blessed",
            "bliss",
            "bloom",
            "bountiful",
            "brave",
            "bright",
            "calm",
            "care",
            "celebrate",
            "change",
            "cherish",
            "clarity",
            "clean",
            "clever",
            "companionship",
            "complete",
            "confident",
            "connect",
            "content",
            "core",
            "courageous",
            "creative",
            "cultivate",
            "cure",
            "curious",
            "dazzling",
            "discover",
            "divine",
            "ecstasy",
            "efficient",
            "electrifying",
            "embrace",
            "encourage",
            "energized",
            "enthusiastic",
            "essence",
            "esteem",
            "exciting",
            "expand",
            "explore",
            "express",
            "faith",
            "flourish",
            "fortunate",
            "freedom",
            "fresh",
            "friendship",
            "funny",
            "gather",
            "genuine",
            "gorgeous",
            "grace",
            "gratitude",
            "grow",
            "happy",
            "harmony",
            "healing",
            "healthy",
            "heavenly",
            "helpful",
            "holy",
            "honest",
            "honor",
            "imaginative",
            "independent",
            "inspire",
            "intelligence",
            "intuitive",
            "inventive",
            "joy",
            "kind",
            "knowledge",
            "laugh",
            "leader",
            "light",
            "love",
            "lucrative",
            "marvelous",
            "master",
            "meditate",
            "miracle",
            "natural",
            "nourish",
            "novel",
            "nutritious",
            "optimistic",
            "paradise",
            "peace",
            "perfect",
            "plentiful",
            "poise",
            "powerful",
            "prosperous",
            "protect",
            "proud",
            "purpose",
            "refinement",
            "rejoice",
            "rejuvenate",
            "replenish",
            "respect",
            "revolutionize",
            "rewarding",
            "secure",
            "serenity",
            "shine",
            "smooth",
            "soul",
            "spiritual",
            "spontaneous",
            "style",
            "success",
            "surprise",
            "sustain",
            "team",
            "thankful",
            "therapeutic",
            "transform",
            "triumph",
            "trust",
            "unity",
            "victory",
            "visualize",
            "wealthy",
            "wonderful",
            ]
        
        // Puts wordsArray into TestWords Entity
        for word in wordsArray{
            let newWord = NSEntityDescription.insertNewObject(forEntityName: "TestWords", into: context)
            newWord.setValue(word, forKey: "word") // "word" representing the index in wordsArray
            
            do{
                try context.save() // saves words into array
                print("saved!") // prints the save
            }
            catch{
                
            }
        }
        
    }
    
}

