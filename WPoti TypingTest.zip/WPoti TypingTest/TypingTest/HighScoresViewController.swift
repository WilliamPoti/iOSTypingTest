
import UIKit
import CoreData

struct User {
    var userName:String
    var wpmScore:Int
}

class HighScoresViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var userArray:[User] = []
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.getData()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getData(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"HighScores")
        request.returnsObjectsAsFaults = false
        
        do{
            let results = try context.fetch(request)
            if results.count > 0{
                for result in results as! [NSManagedObject]{
                    let userName = result.value(forKey: "username") as? String
                    let score = result.value(forKey: "scores") as? String
                    let scoreInt = Int(score!)
                    let user = User(userName: userName!, wpmScore: scoreInt!)
                    userArray.append(user)
                    userArray.sort { (lhs: User, rhs: User) -> Bool in
                        // you can have additional code here
                        return lhs.wpmScore > rhs.wpmScore
                    }
                }
            }
            print(userArray)
            self.tableView.reloadData()

        }
        catch{
            
        }
        
    }
    
    func deleteHighScores() {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let context = delegate.persistentContainer.viewContext
        
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "HighScores")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
            self.tableView.reloadData()

        } catch {
            print ("There was an error")
        }

    }
    
    @IBAction func backTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func resetHighScoresTapped(_ sender: Any) {
        let alertController = UIAlertController(title: "Reset?", message:
            "Reset High Scores?", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default,handler: nil))
        let resetAction = UIAlertAction.init(title: "Yes", style: UIAlertActionStyle.default) { (action) in
            self.deleteHighScores()
        }
        alertController.addAction(resetAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.userArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let user = userArray[indexPath.row]
        let cell:UITableViewCell = UITableViewCell.init(style: .subtitle, reuseIdentifier: "score")
        cell.detailTextLabel?.text = "WPM: \(user.wpmScore)"
        cell.textLabel?.text = user.userName
        return cell
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
