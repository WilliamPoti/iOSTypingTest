package com.example.jkozlevcar.bottomnavigationex1.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.util.Set;
import java.util.TreeSet;

public class Preferences {
    public static final String KEY_INSERTED = "inserted_in_database";
    private static final String KEY_FAVORITES = "favs";

    SharedPreferences sharedPreferences;

    public Preferences(Context context) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    // prevents multiple insertions into the database
    // checks if previously added info into database
    public boolean hasInsertedInDatabase() {
        return sharedPreferences.getBoolean(KEY_INSERTED, false);
    }

    // set the initial insertion key into the file
    public void setHasInsertedInDatabase() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_INSERTED, true);
        editor.apply();
    }

    //add a champion as favorites
    public boolean addChampionToFavorites(String name) {
        //get the list of champions from the database and add the name given as parameter
        Set<String> favs = sharedPreferences.getStringSet(KEY_FAVORITES, new TreeSet<String>());
        favs.add(name);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putStringSet(KEY_FAVORITES, favs);
        return editor.commit();
    }

    //remove a champion from favorites
    public boolean removeChampionFromFavorites(String name) {
        Set<String> favs = sharedPreferences.getStringSet(KEY_FAVORITES, new TreeSet<String>());
        favs.remove(name);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putStringSet(KEY_FAVORITES, favs);
        return editor.commit();
    }

    //check if a certain item is set as favorite
    public boolean isSetAsFavorite(String name) {
        Set<String> favs = sharedPreferences.getStringSet(KEY_FAVORITES, new TreeSet<String>());
        return favs.contains(name);
    }

    //removes favorites
    public void removeAllFavorites() {
        SharedPreferences.Editor e = sharedPreferences.edit();
        e.putStringSet(KEY_FAVORITES, new TreeSet<String>());
        e.commit();
    }
}
