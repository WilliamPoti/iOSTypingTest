package com.example.jkozlevcar.bottomnavigationex1.model;

public class Spell {

    private String range;

    private String image;

    //build a spell object by range and demo image
    public Spell(String range, String image) {
        this.range = range;
        this.image = image;
    }

    /**
     * Getters and Setters
     * @return
     */
    public String getRange() {
        return range;
    }

    public Spell setRange(String range) {
        this.range = range;
        return this;
    }

    public String getImage() {
        return image;
    }

    public Spell setImage(String image) {
        this.image = image;
        return this;
    }
}
