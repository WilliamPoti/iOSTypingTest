// Project:         League of Legends Spell Range Tool
// Class:           MainActivity.java
// Date:            3/5/17
// Author:          W. Poti
// File:            DtabaseHandler.java
// Description:     This class handles all database activity

package com.example.jkozlevcar.bottomnavigationex1.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "champions";

    // table names
    private static final String TABLE_RANGE = "range";

    // course Table columns names
    private static final String COL_ID = "_id";
    private static final String COL_NAME = "name";
    private static final String COL_ATTACK = "attack";
    private static final String COL_ATTACK_IMAGE = "attack_image";
    private static final String COL_SPELL1 = "spell1";
    private static final String COL_SPELL2 = "spell2";
    private static final String COL_SPELL3 = "spell3";
    private static final String COL_SPELL4 = "spell4";
    private static final String COL_IMAGE1 = "image1";
    private static final String COL_IMAGE2 = "image2";
    private static final String COL_IMAGE3 = "image3";
    private static final String COL_IMAGE4 = "image4";


    // constructor
    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("SQLite onCreate called");
        // SQLite Create syntax
        //CREATE TABLE NameOfTable(Column1 Type, Column2 Type);

        // Lab9
        // declare string with SQL command to create the Champion table
        String CREATE_RANGE_TABLE = "CREATE TABLE " + TABLE_RANGE + "("
                + COL_ID + " INTEGER PRIMARY KEY,"
                + COL_NAME + " TEXT,"
                + COL_ATTACK + " TEXT,"
                + COL_ATTACK_IMAGE + " TEXT,"
                + COL_SPELL1 + " TEXT,"
                + COL_SPELL2 + " TEXT,"
                + COL_SPELL3 + " TEXT,"
                + COL_SPELL4 + " TEXT,"
                + COL_IMAGE1 + " TEXT,"
                + COL_IMAGE2 + " TEXT,"
                + COL_IMAGE3 + " TEXT,"
                + COL_IMAGE4 + " TEXT"
                + ")";

        db.execSQL(CREATE_RANGE_TABLE);
    }

    // Lab9
    // add a champion champion to the champion table
    public void addRange(Champion champion) {
        // get the database from the SQLiteHelper
        SQLiteDatabase db = this.getWritableDatabase();

        // ContentValues is used to store a set of key/values that the ContentResolver can process.
        // These values will be inserted into the matching columns
        ContentValues values = new ContentValues();
        values.put(COL_NAME, champion.getName());                    // champion name
        values.put(COL_ATTACK, champion.getAttack().getRange());                  // champion attack
        values.put(COL_ATTACK_IMAGE, champion.getAttack().getImage());                  // champion attack
        values.put(COL_SPELL1, champion.getSpells().get(0).getRange());                  // champion spell1
        values.put(COL_IMAGE1, champion.getSpells().get(0).getImage());     // champion links1
        values.put(COL_SPELL2, champion.getSpells().get(1).getRange());   // champion spell2
        values.put(COL_IMAGE2, champion.getSpells().get(1).getImage());     // champion links2
        values.put(COL_SPELL3, champion.getSpells().get(2).getRange());       // champion spell3
        values.put(COL_IMAGE3, champion.getSpells().get(2).getImage());     // champion links3
        values.put(COL_SPELL4, champion.getSpells().get(3).getRange());     // champion spell4
        values.put(COL_IMAGE4, champion.getSpells().get(3).getImage());     // champion links4

        // Inserting Row
        // SQLite Syntax
        // INSERT INTO TableName(ColumnValue, ColumnValue)

        // Use the SQLite insert method
        // first arg is table name
        // second arg If you specify null, like in this code sample,
        // the framework does not insert a row when there are no values.
        db.insert(TABLE_RANGE, null, values);

        db.close(); // Closing database connection
    }

    // get Champion entry from range table and return as Champion object
    public Champion getChampionByName(String someName) {
        // create reference to ChampionRange for return
        Champion champion = null;

        try {
            // get the database from the SQLiteHelper
            SQLiteDatabase db = this.getReadableDatabase();

            // SQLite query command
            // query(String table, String[] columns, String selection, String[] selectionArgs,
            //          String groupBy, String having, String orderBy, String limit)
            Cursor cursor = db.query(TABLE_RANGE, new String[]{COL_ID,
                            COL_NAME, COL_ATTACK, COL_SPELL1, COL_SPELL2, COL_SPELL3, COL_SPELL4}, COL_NAME + "=?",
                    new String[]{someName}, null, null, null, null);

            // if the cursor is not null and count is > 0, move to the first position.
            if (cursor != null && cursor.getCount() > 0) {
                cursor.moveToFirst();

                // create ChampionRange object from cursor

                Spell att = new Spell(cursor.getString(cursor.getColumnIndex(COL_ATTACK)), cursor.getString(cursor.getColumnIndex(COL_ATTACK_IMAGE)));
                Spell s1 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL1)), cursor.getString(cursor.getColumnIndex(COL_IMAGE1)));
                Spell s2 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL2)), cursor.getString(cursor.getColumnIndex(COL_IMAGE2)));
                Spell s3 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL3)), cursor.getString(cursor.getColumnIndex(COL_IMAGE3)));
                Spell s4 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL4)), cursor.getString(cursor.getColumnIndex(COL_IMAGE4)));
                champion = new Champion(cursor.getString(cursor.getColumnIndex(COL_SPELL4)), att, s1, s2, s3, s4);

                //close the cursor
                cursor.close();
            } else {
                System.out.println("getChampionByName cursor is null");
                champion = null;
            }

            // close the database
            db.close();

            // return champion
            return champion;

        } catch (Exception e) {
            System.out.println(e.getMessage());
            // return champion
            return champion;
        }
    }

    // get all Ranges from the range table
    public List<Champion> getAllRange() {

        String selectQuery = "SELECT *" + " FROM " + TABLE_RANGE + " ORDER BY " + COL_NAME;

        // get the database from the SQLiteHelper
        SQLiteDatabase db = this.getReadableDatabase();

        // execute a raw SQLite query
        Cursor cursor = db.rawQuery(selectQuery, null);

        List<Champion> champions = new ArrayList<>();
        if(cursor != null && cursor.moveToFirst()) {
            do {

                Spell att = new Spell(cursor.getString(cursor.getColumnIndex(COL_ATTACK)), cursor.getString(cursor.getColumnIndex(COL_ATTACK_IMAGE)));
                Spell s1 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL1)), cursor.getString(cursor.getColumnIndex(COL_IMAGE1)));
                Spell s2 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL2)), cursor.getString(cursor.getColumnIndex(COL_IMAGE2)));
                Spell s3 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL3)), cursor.getString(cursor.getColumnIndex(COL_IMAGE3)));
                Spell s4 = new Spell(cursor.getString(cursor.getColumnIndex(COL_SPELL4)), cursor.getString(cursor.getColumnIndex(COL_IMAGE4)));
                Champion champion = new Champion(cursor.getString(cursor.getColumnIndex(COL_NAME)), att, s1, s2, s3, s4);

                champions.add(champion);
            } while (cursor.moveToNext());
            cursor.close();
            db.close();
        }

        // return the Cursor
        return champions;

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        System.out.println("SQLite onUpgrade called");
        // Drop older table if existed

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RANGE);

        // Create tables again
        onCreate(db);
    }
}

