// Project:         League of Legends Spell Range Tool
// Class:           MainActivity.java
// Date:            3/5/17
// Author:          W. Poti
// Description:     Application that uses fragments and a database to display information for learning League of Legends, visually and numerically

package com.example.jkozlevcar.bottomnavigationex1.activities;

import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.jkozlevcar.bottomnavigationex1.R;
import com.example.jkozlevcar.bottomnavigationex1.fragments.FragmentNumeric;
import com.example.jkozlevcar.bottomnavigationex1.fragments.FragmentVisual;
import com.example.jkozlevcar.bottomnavigationex1.model.Champion;
import com.example.jkozlevcar.bottomnavigationex1.model.DatabaseHandler;
import com.example.jkozlevcar.bottomnavigationex1.model.DatabaseTest;
import com.example.jkozlevcar.bottomnavigationex1.util.Preferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private static final String KEY_CURRENT_FRAGMENT = "current_selected_fragment";
    private static final String FRAGMENT_TAG_VISUALS = "visuals";
    private static final String FRAGMENT_TAG_NUMERICS = "numerics";
    private static final String KEY_CURRENT_CHAMPION = "current_champion";

    private Spinner spChampions;

    // Database Handler instance
    private DatabaseHandler dbh;

    // All champions list from the database
    private List<Champion> champions;

    // List of Champion names for Spinner Adapter
    private List<String> champNames;

    // Current Spinner Selection
    private Champion activeChampion;

    // Custom Shared Preferences Helper class
    private Preferences preferences;

    // fragment instances
    private FragmentVisual fragmentVisuals;
    private FragmentNumeric fragmentNumerics;

    // seeing the numerics fragment first
    private String fragmentTag = "numerics";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        dbh = new DatabaseHandler(this);
        preferences = new Preferences(this);

        // query shared preferences for insertion flag
        if(!preferences.hasInsertedInDatabase()) {
            // running insert queries for first app start
            DatabaseTest.testRangeTable(this);

            // set the insertion flag to true in shared preferences
            preferences.setHasInsertedInDatabase();
        }
        // get a list of all Champions from db
        champions = dbh.getAllRange();


        // getting names from the list of champions
        Set<String> champions = new HashSet<>();
        for (Champion r : this.champions) champions.add(r.getName());
        champNames = new ArrayList<>(champions);
        //sorting alphabetically
        Collections.sort(champNames);

        //  create the bottom navigation controller
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);

        // set the navigation on item selection listener
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Log.i("Final", "NavigationItemSelected called");

                // define fragment reference to hold selected fragment
                Fragment selectedFragment = null;
                fragmentTag = null;

                switch (item.getItemId()) {
                    case R.id.menu_visuals:
                        // use the visuals fragment
                        selectedFragment = fragmentVisuals;
                        fragmentTag = FRAGMENT_TAG_VISUALS;
                        break;
                    case R.id.menu_numerics:
                        // use the numerics fragment
                        selectedFragment = fragmentNumerics;
                        fragmentTag = FRAGMENT_TAG_NUMERICS;
                        break;
                }

                // replace the current fragment with the selected fragment
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.content, selectedFragment, fragmentTag);
                transaction.commit();

                // tell the fragments that the active fragment has been changed
                dispatchToFragments(activeChampion);

                return true;
            }
        });

        spChampions = findViewById(R.id.spChampions);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        activeChampion = this.champions.get(0);

        fragmentVisuals = FragmentVisual.newInstance();
        fragmentNumerics = FragmentNumeric.newInstance();


        // Manually displaying the first fragment - one time only
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.content, fragmentNumerics);
        transaction.commit();

        // restore the selected fragment on orientation change
        if (savedInstanceState != null) {
            String selectedFragment = savedInstanceState.getString(KEY_CURRENT_FRAGMENT);

            // selects the fragment that was on display before orientation change
            if (selectedFragment != null) {
                switch (selectedFragment) {
                    case FRAGMENT_TAG_NUMERICS:
                        navigation.setSelectedItemId(R.id.menu_numerics);
                        break;
                    case FRAGMENT_TAG_VISUALS:
                        navigation.setSelectedItemId(R.id.menu_visuals);
                        break;
                    default:
                        Log.d(MainActivity.class.getName(), "How did you get here?!?");
                        break;
                }
            }
        } else {
            // Used to select an item in the bottom navigation programmatically
            navigation.getMenu().getItem(0).setChecked(true);
        }

        // build the adapter for the Spinner
        setAdapter();

    }

    private void setAdapter() {
        // resorting the collection alphabetically AND bring the favorites to the top
        Collections.sort(champNames, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                boolean firstFav = preferences.isSetAsFavorite(o1);
                boolean secondFav = preferences.isSetAsFavorite(o2);

                if(firstFav && secondFav) {
                    return 0;
                } else if(firstFav) {
                    return -1;
                } else if(secondFav) {
                    return 1;
                }

                return o1.compareTo(o2);
            }
        });

        // build the adapter with our champions names strings
        ArrayAdapter<String> champsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, champNames);
        spChampions.setAdapter(champsAdapter);
    }

    // search the list for a certain champion by name
    // uses local champions list instead of looking into the database(faster)
    private Champion findByName(String name) {
        for (Champion r : champions) {
            if (r.getName().equals(name)) {
                return r;
            }
        }

        return null;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putString(KEY_CURRENT_FRAGMENT, fragmentTag);
        outState.putString(KEY_CURRENT_CHAMPION, activeChampion.getName());

        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // setting the listener for spinner item selected change
        spChampions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // get the name of the selected champion
                String name = champNames.get(position);

                // get the Champion object with the name of our current selection
                activeChampion = findByName(name);

                // send the Champion object to the fragments to load the data
                dispatchToFragments(activeChampion);

                // resets the heart icon
                invalidateOptionsMenu();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // build the heart options menu
        getMenuInflater().inflate(R.menu.favorites_menu, menu);
        // check if the current selection is favorited
        if(preferences.isSetAsFavorite(activeChampion.getName())) {
            //if yes, then ake the heart highlighted
            menu.findItem(R.id.menu_favorites).setIcon(R.drawable.full_heart);
        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // check if the item clicked is the heart
        if(item.getItemId() == R.id.menu_favorites) {
            // if the champion was previously favorite, we want to remove it from favorites
            if(preferences.isSetAsFavorite(activeChampion.getName())) {
                if(preferences.removeChampionFromFavorites(activeChampion.getName())) {
                    Toast.makeText(this, activeChampion.getName() + " removed from Favorites", Toast.LENGTH_LONG).show();
                    item.setIcon(R.drawable.empty_heart);
                }
            } else {
                // if it wasn't previously favorite, then we want to add it to favorites
                if(preferences.addChampionToFavorites(activeChampion.getName())) {
                    Toast.makeText(this, activeChampion.getName() + " added to Favorites", Toast.LENGTH_LONG).show();
                    item.setIcon(R.drawable.full_heart);
                }
            }

            return true;
        } else if(item.getItemId() == R.id.menu_remove_all) {
            // building a dialog
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setTitle("Alert!!!")
                    .setMessage("Remove all favorite champions?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //call the remove favorites method
                            preferences.removeAllFavorites();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //dismiss the dialog otherwise
                            dialog.dismiss();
                        }
                    });

            // showing the dialog
            dialog.show();
        }

        return super.onOptionsItemSelected(item);
    }

    private void dispatchToFragments(Champion selected) {
        // send our current selected item to the fragments to be displayed
        fragmentVisuals.setNewChampionSelected(selected);
        fragmentNumerics.setNewChampionSelected(selected);
    }

    @Override
    protected void onPause() {
        super.onPause();

        // if the app is closing, close the database also
        if (isFinishing()) dbh.close();
    }
}
