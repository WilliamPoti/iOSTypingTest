// Project:         League of Legends Spell Range Tool
// Class:           MainActivity.java
// Date:            3/5/17
// Author:          W. Poti
// File:        Champion.java
// Description: Holds information for each champion

package com.example.jkozlevcar.bottomnavigationex1.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Champion {

    // private instance fields
    private String name;
    private Spell attack;

    private List<Spell> spells;

    // construct a Champion object based on name and ability spells
    public Champion(String name, Spell attack, Spell spell1, Spell spell2, Spell spell3, Spell spell4) {
        this.name = name;
        this.attack = attack;

        spells = new ArrayList<>();
        spells.add(spell1);
        spells.add(spell2);
        spells.add(spell3);
        spells.add(spell4);
    }

    /**
     * Getters and setters for the properties
     * @return
     */
    public String getName() {
        return name;
    }

    public Champion setName(String name) {
        this.name = name;
        return this;
    }

    public Spell getAttack() {
        return attack;
    }

    public Champion setAttack(Spell attack) {
        this.attack = attack;
        return this;
    }


    public List<Spell> getSpells() {
        return spells;
    }

    //formats the list of spells to print it in a textview
    public String getSpellsFormatted(String delimiter) {
        StringBuilder allSpells = new StringBuilder();

        int i = 1;
        allSpells.append(String.format(Locale.getDefault(),"Auto Attack Range: %s", attack.getRange())).append(delimiter);
        for(Spell spell : spells) {
            //adding the spell info to the printed string
            allSpells.append(String.format(Locale.getDefault(),"Spell %d Range: %s", i++, spell.getRange())).append(delimiter);
        }

        return allSpells.toString();
    }
}
