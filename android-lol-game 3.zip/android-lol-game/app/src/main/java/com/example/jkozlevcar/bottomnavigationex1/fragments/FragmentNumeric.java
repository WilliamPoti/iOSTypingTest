// Project:         League of Legends Spell Range Tool
// Class:           MainActivity.java
// Date:            3/5/17
// Author:          W. Poti
// Description:     Fragment for numeric data of spells/attack ranges

package com.example.jkozlevcar.bottomnavigationex1.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.jkozlevcar.bottomnavigationex1.R;
import com.example.jkozlevcar.bottomnavigationex1.model.Champion;


public class FragmentNumeric extends Fragment {
    // Declares Variables
    private Champion activeChampion;

    private TextView championName;
    private TextView championSpells;

    // class method to create and return object of the fragment
    public static FragmentNumeric newInstance() {
        return new FragmentNumeric();
    }

    // Set the champion selected
    public void setNewChampionSelected(Champion selected) {
        activeChampion = selected;

        // set the text views values with the name and spells
        if (getActivity() != null && selected != null) {
            championName.setText(activeChampion.getName());
            championSpells.setText(activeChampion.getSpellsFormatted("\n"));
        }
    }

    // Called to create the view hierarchy associated with the fragment.
    // container from Activity holding the fragment.
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // inflate the xml layout file into the fragment, save the rootview
        View rootView = inflater.inflate(R.layout.fragment_numeric, container, false);

        championName = rootView.findViewById(R.id.tvChampionName);
        championSpells = rootView.findViewById(R.id.tvChampionSpells);

        setNewChampionSelected(activeChampion);

        return rootView;
    }
}
