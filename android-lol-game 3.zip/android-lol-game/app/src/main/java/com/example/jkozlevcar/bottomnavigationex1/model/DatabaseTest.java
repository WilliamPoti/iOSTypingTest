package com.example.jkozlevcar.bottomnavigationex1.model;

// Project:         League of Legends Spell Range Tool
// Class:           MainActivity.java
// Date:            3/5/17
// Author:          W. Poti
// Description:     This class tests creating, adding, deleting and listing of the Range table


import android.content.Context;

import java.util.List;


// class is abstract because there is no need to create an object
// It is only used to hold methods to test the database
public abstract class DatabaseTest {

    // Lab9
    public static void testRangeTable(Context context) {
        // create the database handler object
        DatabaseHandler dbh = new DatabaseHandler(context);

        try {
            // create champions to add to range table
            Spell attack = new Spell( "600", "https://i.imgur.com/p5R3ElT.png");
            Spell s1 = new Spell( "none", "https://i.imgur.com/fn4VDQc.png");
            Spell s2 = new Spell( "1200", "https://i.imgur.com/rSy9JSf.png");
            Spell s3 = new Spell( "global", "https://i.imgur.com/1q6e0x8.png");
            Spell s4 = new Spell( "global", "https://i.imgur.com/BL0UsPy.png");
            Champion champion1 = new Champion("Ashe", attack, s1, s2, s3, s4);

            attack = new Spell( "650", "https://i.imgur.com/WH5rrMg.png");
            s1 = new Spell( "1250", "https://i.imgur.com/WH5rrMg.png");
            s2 = new Spell( "800", "https://i.imgur.com/zBBN89p.png");
            s3 = new Spell( "750", "https://i.imgur.com/jvc0Mg8.png");
            s4 = new Spell( "2500", "https://i.imgur.com/rUHSwNR.png");
            Champion champion2 = new Champion("Caitlyn", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/msRm8xH.png");
            s1 = new Spell( "none", "https://i.imgur.com/xrL2qSk.png");
            s2 = new Spell( "none", "https://i.imgur.com/STWetIT.png");
            s3 = new Spell( "1050", "https://i.imgur.com/lKOWDZA.png");
            s4 = new Spell( "global", "https://i.imgur.com/ODwpqrQ.png");
            Champion champion4 = new Champion("Draven", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/z9iKoDC.png");
            s1 = new Spell( "1150", "https://i.imgur.com/sGPgCSV.png");
            s2 = new Spell( "1000", "https://i.imgur.com/FgpScsf.png");
            s3 = new Spell( "450", "https://i.imgur.com/AtPswiq.png");
            s4 = new Spell( "global", "https://i.imgur.com/WGlzYYS.png");
            Champion champion5 = new Champion("Ezreal", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/AD5zQfC.png");
            s1 = new Spell( "550", "https://i.imgur.com/8ZfUdjn.png");
            s2 = new Spell( "3000", "https://i.imgur.com/kocrYzy.png");
            s3 = new Spell( "750", "https://i.imgur.com/mV3ePxG.png");
            s4 = new Spell( "3500", "https://i.imgur.com/o0Lg4x3.png");
            Champion champion6 = new Champion("Jhin", attack, s1, s2, s3, s4);

            attack = new Spell( "525", "https://i.imgur.com/8HHq7A4.png");
            s1 = new Spell( "675", "https://i.imgur.com/r5DnEfi.png");
            s2 = new Spell( "1450", "https://i.imgur.com/HW7q93G.png");
            s3 = new Spell( "900", "https://i.imgur.com/sufbiYG.png");
            s4 = new Spell( "global", "https://i.imgur.com/iXBEhSC.png");
            Champion champion7 = new Champion("Jinx", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/QJqXJbO.png");
            s1 = new Spell( "1150", "https://i.imgur.com/ln2zDMj.png");
            s2 = new Spell( "none", "https://i.imgur.com/hOxc6R4.png");
            s3 = new Spell( "none", "https://i.imgur.com/gM40URf.png");
            s4 = new Spell( "1200", "https://i.imgur.com/5Co8UmD.png");
            Champion champion8 = new Champion("Kalista", attack, s1, s2, s3, s4);

            attack = new Spell( "500", "https://i.imgur.com/3MhPZf8.png");
            s1 = new Spell( "1175", "https://i.imgur.com/XrwIXCL.png");
            s2 = new Spell( "none", "https://i.imgur.com/ZjepfU3.png");
            s3 = new Spell( "1280", "https://i.imgur.com/Vqc9k2J.png");
            s4 = new Spell( "1200", "https://i.imgur.com/WXQU0AO.png");
            Champion champion10 = new Champion("Kog'Maw", attack, s1, s2, s3, s4);

            attack = new Spell( "500", "https://i.imgur.com/hIKU7fd.png");
            s1 = new Spell( "900", "https://i.imgur.com/PxYb72K.png");
            s2 = new Spell( "900", "https://i.imgur.com/4bNY2aS.png");
            s3 = new Spell( "425", "https://i.imgur.com/rTp6F1C.png");
            s4 = new Spell( "1200", "https://i.imgur.com/Cx1fImq.png");
            Champion champion11 = new Champion("Lucian", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/VNi8kQb.png");
            s1 = new Spell( "650", "https://i.imgur.com/xddeAFU.png");
            s2 = new Spell( "none", "https://i.imgur.com/uBJddd9.png");
            s3 = new Spell( "1000", "https://i.imgur.com/Cd5GWXf.png");
            s4 = new Spell( "1400", "https://i.imgur.com/D3YBmCW.png");
            Champion champion12 = new Champion("Miss Fortune", attack, s1, s2, s3, s4);

            attack = new Spell( "500", "https://i.imgur.com/e9EVSDX.png");
            s1 = new Spell( "1250", "https://i.imgur.com/gyfAcvl.png");
            s2 = new Spell( "none", "https://i.imgur.com/NRV28LW.png");
            s3 = new Spell( "none", "https://i.imgur.com/Pw3pvQr.png");
            s4 = new Spell( "none", "https://i.imgur.com/LrSINIn.png");
            Champion champion13 = new Champion("Sivir", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/ds90Efv.png");
            s1 = new Spell( "none", "https://i.imgur.com/gX6CYfB.png");
            s2 = new Spell( "900", "https://i.imgur.com/2IUTaup.png");
            s3 = new Spell( "550", "https://i.imgur.com/maO7xeD.png");
            s4 = new Spell( "550", "https://i.imgur.com/bGFyaat.png");
            Champion champion14 = new Champion("Tristana", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/0hS40rx.png");
            s1 = new Spell( "none", "https://i.imgur.com/6GgmaUY.png");
            s2 = new Spell( "900", "https://i.imgur.com/yKc8f8z.png");
            s3 = new Spell( "1200", "https://i.imgur.com/NHfwXVW.png");
            s4 = new Spell( "825", "https://i.imgur.com/rmYGLvX.png");
            Champion champion15 = new Champion("Twitch", attack, s1, s2, s3, s4);

            attack = new Spell( "575", "https://i.imgur.com/BBjhb48.png");
            s1 = new Spell( "1625", "https://i.imgur.com/vKH6pkE.png");
            s2 = new Spell( "none", "https://i.imgur.com/fVn84lJ.png");
            s3 = new Spell( "925", "https://i.imgur.com/z23uabD.png");
            s4 = new Spell( "1075", "https://i.imgur.com/3zTe3ko.png");
            Champion champion16 = new Champion("Varus", attack, s1, s2, s3, s4);

            attack = new Spell( "550", "https://i.imgur.com/sPMG5Bk.png");
            s1 = new Spell( "300", "https://i.imgur.com/JJ14oXa.png");
            s2 = new Spell( "none", "https://i.imgur.com/5k7lCye.png");
            s3 = new Spell( "550", "https://i.imgur.com/lp2WiIJ.png");
            s4 = new Spell( "none", "https://i.imgur.com/5bmr2f4.png");
            Champion champion17 = new Champion("Vayne", attack, s1, s2, s3, s4);

            attack = new Spell( "525", "https://i.imgur.com/fNSgHCO.png");
            s1 = new Spell( "1100", "https://i.imgur.com/4NRaZPL.png");
            s2 = new Spell( "none", "https://i.imgur.com/Dgirv5V.png");
            s3 = new Spell( "global", "https://i.imgur.com/eeGgGeR.png");
            s4 = new Spell( "1100", "https://i.imgur.com/mif17sn.png");
            Champion champion18 = new Champion("Xayah", attack, s1, s2, s3, s4);
            // add the Champion to the Champion table
            dbh.addRange(champion1);
            dbh.addRange(champion2);
//            dbh.addRange(champion3);
            dbh.addRange(champion4);
            dbh.addRange(champion5);
            dbh.addRange(champion6);
            dbh.addRange(champion7);
            dbh.addRange(champion8);
//            dbh.addRange(champion9);
            dbh.addRange(champion10);
            dbh.addRange(champion11);
            dbh.addRange(champion12);
            dbh.addRange(champion13);
            dbh.addRange(champion14);
            dbh.addRange(champion15);
            dbh.addRange(champion16);
            dbh.addRange(champion17);
            dbh.addRange(champion18);

            // test method getChampionByName()
            System.out.println("Test getChampionByName(\"N3\").png");
            Champion champion = dbh.getChampionByName("N3.png");
            System.out.println(champion);
            System.out.println(" .png");

            // test method getAllRange()
            System.out.println("Test getAllRange().png");
            List<Champion> allChampion = dbh.getAllRange();
            System.out.println("allChampion size: " + allChampion.size());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}