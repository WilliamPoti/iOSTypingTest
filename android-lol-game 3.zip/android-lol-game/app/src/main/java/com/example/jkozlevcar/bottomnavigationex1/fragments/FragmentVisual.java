// Project:         League of Legends Spell Range Tool
// Class:           MainActivity.java
// Date:            3/5/17
// Author:          W. Poti
// Description:     Visual fragment with images of spell ranges

package com.example.jkozlevcar.bottomnavigationex1.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.jkozlevcar.bottomnavigationex1.model.Champion;
import com.example.jkozlevcar.bottomnavigationex1.R;
import com.example.jkozlevcar.bottomnavigationex1.model.Spell;
import com.example.jkozlevcar.bottomnavigationex1.util.Utility;
import com.squareup.picasso.Picasso;


public class FragmentVisual extends Fragment {

    private Champion activeChampion;

    private ImageView ivChampion;
    private LinearLayout llSpellButtons;

    // class method to create and return object of the fragment
    public static FragmentVisual newInstance() {
        FragmentVisual fragment = new FragmentVisual();
        return fragment;
    }

    public FragmentVisual() {}

    //use Picasso Library to load images and cache them
    private void loadImage(String url) {
        Picasso.with(getActivity()).load(url).into(ivChampion);
    }

    public void setNewChampionSelected(Champion selected) {
        activeChampion = selected;
        //TODO change some things after setting this one(texts and image)

        //if the activity is running and we have a selected champion
        if (getActivity() != null && activeChampion != null) {
            //check internet connection available
            if(Utility.isOnline(getActivity())) {
                //load the image from imgur
                loadImage(activeChampion.getAttack().getImage());

                //clear the previous buttons(if any)
                llSpellButtons.removeAllViews();
                int i = 1;

                //create the spell buttons dynamically; building buttons using Java and not XML;
                //add buttons to the layout on runtime
                Button button = new Button(getActivity());
                button.setText(R.string.auto_attack);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loadImage(activeChampion.getAttack().getImage());
                    }
                });

                llSpellButtons.addView(button);

                // makes buttons based on how many spells
                for(final Spell s : activeChampion.getSpells()) {
                    button = new Button(getActivity());
                    button.setText(String.format("Spell %d", i++));
                    //when the button is pushed, show the spell corresponding image
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            loadImage(s.getImage());
                        }
                    });

                    //add the instantiated button to the layout
                    llSpellButtons.addView(button);
                }

            } else {
                //if we don't have a connection then we don't build any buttons, just set a static image
                ivChampion.setImageDrawable(getResources().getDrawable(R.drawable.no_internet));
            }
        }
    }

    // Called to create the view hierarchy associated with the fragment.
    // container from Activity holding the fragment.
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // inflate the xml layout file into the fragment, save the rootview
        View rootView = inflater.inflate(R.layout.fragment_visual, container, false);

        ivChampion = rootView.findViewById(R.id.ivChampion);
        llSpellButtons = rootView.findViewById(R.id.llSpellButtons);

        setNewChampionSelected(activeChampion);

        return rootView;
    }
}
